Create a App using "Create React App" and add given paragraph on the home screen.

("Welcome to React Course on codingninjas.com")
