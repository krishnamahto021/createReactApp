import "./styles.css";
import Form from './Form';
import HomePage from "./HomePage";


export default function App() {
  return <div className="App">
    <HomePage />
    <Form />
  </div>;
}
