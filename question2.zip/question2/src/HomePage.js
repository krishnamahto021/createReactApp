// Complete the HomePage Component and export it

function HomePage() {
  return (
    <div className="Homepage">
      {/* Create a h1 tag and render Form Component here */}
      <h1>HomePage</h1>
    </div>
  );
}

export default HomePage;
export var name = 'YourName' ;
export var email = 'xyz@pqr.com';
